import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { editdata } from './reducer'

function EditProduct() {
     const [name, setName] = useState("")
      const [price, setPrice] = useState("")
     const prd = useSelector(state => state.data)
      const {id} = useParams()
      const disptach = useDispatch()

    // const prd =  useSelector(state => state.data)

   
     

      useEffect(() => {
             fetch('http://localhost:1234/product/' + id)
                 .then((res) => {return res.json()})
                 .then((data)=> {
                   setName(data.name)
                   setPrice(data.price)
                   
                 })
         },[])
   
             
  
    

const handleedit = (e)=>{
   e.preventDefault()
   disptach(editdata({id:id,name,price}))
   window.location.reload()
   
}




  return (
   <>
    <Link to={'/'} className='btn btn-info'>Home</Link>
    <h2 className='mt-5'>Edit Products</h2>
      <div className='container mt-5'>
        <form className='text-start' onSubmit={handleedit}>
          <div className="mb-3">
            <label className="form-label">Name : </label>
            <input value={name} onChange={(e) => {setName(e.target.value) }} type="text" className="form-control"  />

          </div>
          <div className="mb-3">
            <label className="form-label">Price</label>
            <input value={price} onChange={(e) => {setPrice(e.target.value) }} type="text" className="form-control" id="exampleInputPassword1" />
          </div>

          <button type="submit" className="btn btn-primary">Update Data</button>
        </form>
      </div>

   </>
  )
}

export default EditProduct