import logo from './logo.svg';
import './App.css';
import Json_fetch from './Json-fetch';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import AddData from './AddData';
import EditProduct from './EditProduct';

function App() {
  return (
    <div className="App">
      <h1>Json-server Redux</h1>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Json_fetch></Json_fetch>}></Route>
          <Route path='/add' element={<AddData></AddData>}></Route>
          <Route path='/edit/:id' element={<EditProduct></EditProduct>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
