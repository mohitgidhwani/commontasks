
import { createSlice } from '@reduxjs/toolkit'
import React, { use, useContext, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, useParams } from 'react-router-dom'
import { deldata, setData } from './reducer'

function Json_fetch() {

    

    const [data] = useSelector(state => state.data)
   
   
    
    const {id} = useParams()
    
   
       
  const disptach = useDispatch()

    useEffect(() => {
        fetch('http://localhost:1234/product')
            .then((res) => {return res.json()})
            .then((data)=> {
               disptach (setData(data))
            })
    }, [])
            
   
   
       
   const handleDelete = (id)=>{
       disptach(deldata({id}))

       window.location.reload()
   }

   
   return (
           <>
               <Link to={'/add'} className='btn btn-info'>Add Data</Link>
              <div className='container'>
              <table className="table mt-5">
                   <thead>
                       <tr>
                           <th scope="col">#</th>  
                           <th scope="col">Name</th>
                           <th scope="col">Price</th>
                           <th scope="col">Actions</th>
                       </tr>
                           
                   </thead>
                   <tbody>
                       {data && data.map((user)=>{
                           return (
                               <tr key={user.id}>
                                   <th>{user.id}</th>
                                   <td>{user.name}</td>
                                   <td>{user.price}</td>
                                   
                                   <td>
                                       <Link to={`/edit/${user.id}`} className='btn btn-success mx-1'>Edit</Link>
                                       <button onClick={()=>{handleDelete(user.id)}} className='btn btn-danger'>Delete</button>
                                   </td>
                               </tr>
                               )
                           })}
                   </tbody>
               </table>
              </div>
           </>
       )
   }
   
   export default Json_fetch

     
      
   


