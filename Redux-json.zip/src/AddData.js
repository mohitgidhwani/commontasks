import React, { useState } from 'react'
import { addata } from './reducer'
import { useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'

function AddData() {

  const [name, setName] = useState("")
  const [price, setPrice] = useState("")

  const disptach = useDispatch()

const handleadd = (e)=>{

   e.preventDefault()

   disptach(addata({name,price}))
   window.location.reload()
} 
  


  
  return (
    <>

    <Link to={'/'} className='btn btn-info'>Home</Link>
      <div className='container mt-5'>
        <form className='text-start' onSubmit={handleadd}>
          <div className="mb-3">
            <label className="form-label">Name : </label>
            <input value={name} onChange={(e) => {setName(e.target.value) }} type="text" className="form-control"  />

          </div>
          <div className="mb-3">
            <label className="form-label">Price</label>
            <input value={price} onChange={(e) => {setPrice(e.target.value) }} type="text" className="form-control" id="exampleInputPassword1" />
          </div>

          <button type="submit" className="btn btn-primary">Add Data</button>
        </form>
      </div>

    </>
  )
}

export default AddData