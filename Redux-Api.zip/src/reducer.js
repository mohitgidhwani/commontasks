import { createSlice } from "@reduxjs/toolkit";

const userSlice = createSlice({
    name:"user",
    initialState:[],
    reducers:{
        setData:(state,action)=>{
            return action.payload
        },
        addProduct:(state,action)=>{
            state.push(action.payload)
       },
       editProduct:(state,action)=>{
        //    console.log(state)
           console.log(action.payload)

          const {id,uname,uemail} = action.payload

         const user = state.find((value)=>{
              console.log(value.id)
              return value.id == id
          })
          if(user)
          {
            user.name = uname
            user.email = uemail
          }
       },
       deleteProduct : (state,action)=>{
             console.log(action.payload)

         const {id} =action.payload

           const user =  state.filter((value)=>{
                 return value.id == id
             })

             if(user)
             {
                return state.filter(user => user.id !== id)
             }
             
       }
       
          
    }
})
           

               
           
            

           


export default userSlice.reducer;
export  const {setData , addProduct ,editProduct , deleteProduct} = userSlice.actions;