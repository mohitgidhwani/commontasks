import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { addProduct } from './reducer'


function AddProduct() {

   const data = useSelector(state=>state.users)
   
  

    const [name,setName] = useState("")
    const [email,setEmail] = useState("")

const dispatch = useDispatch()

  const handleAdd = ()=>{
       dispatch(addProduct({id:data.length+1,name,email}))
    }

    
    
    
    return (
        <>
            <h1>Go Back Home</h1>
            <Link to={'/'} className='btn btn-info'>Home</Link>

            <h1>Add Product</h1>

            <div className='container-fluid'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6 text-start'>
                        <form >
                            <div className="mb-3">
                                <label  className="form-label">Name : </label>
                                <input type="text" value={name} onChange={(e)=>{setName(e.target.value)}} className="form-control" id="exampleInputEmail1" />
                                
                            </div>
                            <div className="mb-3">
                                <label htmlFor="exampleInputPassword1" className="form-label">Email :</label>
                                <input type="text" value={email} onChange={(e)=>{setEmail(e.target.value)}} className="form-control" id="exampleInputPassword1"/>
                            </div>
                           
                            <button type="button" onClick={handleAdd} className="btn btn-primary">Add Product</button>
                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}

export default AddProduct