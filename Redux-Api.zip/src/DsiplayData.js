import React, { useContext, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteProduct, setData } from './reducer'
import { Link } from 'react-router-dom'

function DsiplayData() {

    const data = useSelector(state => state.users)



    const dispatch = useDispatch()


    useEffect(() => {
        if (data == "") {
            fetch('https://jsonplaceholder.typicode.com/users')
                .then((res) => { return res.json() })
                .then((data) => {
                    dispatch(setData(data));
                })
            }
        }, [])
                   

    const handleDelete = (id)=>{
          dispatch(deleteProduct({id}))
          
    }
    return (
        <>
            <Link to={'/add'} className='btn btn-info'>Add</Link>
            <div className='container'>
                <table className="table mt-5">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Actions</th>
                        </tr>

                    </thead>
                    <tbody>
                        {data && data.map((user) => {
                            return (
                                <tr key={user.id}>
                                    <th>{user.id}</th>
                                    <td>{user.name}</td>
                                    <td>{user.email}</td>

                                    <td>
                                        <Link to={'/edit/' + user.id} className='btn btn-success mx-1'>Edit</Link>
                                        <button onClick={()=>{handleDelete(user.id)}} className='btn btn-danger'>Delete</button>
                                    </td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        </>

    )
}

export default DsiplayData