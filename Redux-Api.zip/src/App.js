import logo from './logo.svg';
import './App.css';
import { useSelector } from 'react-redux';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import DsiplayData from './DsiplayData';
import AddProduct from './AddProduct';
import Edit from './Edit';

function App() {

  return (
    <>
      <div className="App">
        <h2>Redux APi Crud</h2>
        <BrowserRouter >
          <Routes>
            <Route path='/' element={<DsiplayData></DsiplayData>}></Route>
            <Route path='/add' element={<AddProduct></AddProduct>}></Route>
            <Route path='/edit/:id' element={<Edit></Edit>}></Route>
          </Routes>
        </BrowserRouter>
      </div>


    </>
  );
}

export default App;
