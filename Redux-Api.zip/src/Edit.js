import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom'
import { editProduct } from './reducer';

function Edit() {
    const user = useSelector(state => state.users)
    const dispatch = useDispatch()
    const { id } = useParams()

     
    const user_id = user.filter((prd) => {
        return prd.id == id
    })



    const { name, email } = user_id[0]


    const [uname, setUname] = useState(name)
    const [uemail, setuEmail] = useState(email)

  const handleEdit = ()=>{
     dispatch(editProduct({id:id,uname,uemail}))
  }


    return (
        <>
            <div>
                <div className="container-fluid ">
                    <div className="row justify-content-center">
                        <div className="col-xl-6 text-start">
                            <div>
                                <h2>Edit Products Details</h2>
                                <Link to='/' className="btn btn-info my-3">Go Back</Link>
                            </div>
                            <form>
                                <div className="mb-3">
                                    <label>
                                        Name :
                                    </label>
                                    <input
                                        className='form-control'
                                        type="text"
                                        value={uname}
                                        onChange={(e) => {
                                            setUname(e.target.value)
                                        }}
                                    />

  
                                       <br></br>
                                    <input
                                        className='form-control'
                                        type="text"
                                        value={uemail}
                                        onChange={(e) => {
                                            setuEmail(e.target.value)
                                        }}
                                    />
                                </div>
                                <button type="button" onClick={handleEdit} className="btn btn-primary">
                                    Edit Product
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Edit