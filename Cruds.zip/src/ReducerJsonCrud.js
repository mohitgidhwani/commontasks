import { type } from '@testing-library/user-event/dist/type';
import React, { useEffect, useReducer, useState } from 'react'


 const initialstate = "http://localhost:1234/data"

 const reducerfun = (state,action)=>{
      // console.log(state)
      // console.log(action.payload)

      switch(action.type)
      {
        case "print" :
          return action.payload


          case "Add":
            
            return  [...state, action.payload];
           
            
            case "edit":
              console.log(action.payload)
            console.log(state)

            return state.map((value)=>{
                if(value.id == action.payload.id)
                {
                  return action.payload
                }
                else
                {
                  return value
                }
            })

            case "del" : 
            return state.filter((value)=>{
                   return  value.id !== action.payload.id
            })
      }
 }


function ReducerJsonCrud() {

  const [data, setData] = useState("")

  const [state,dispatch] = useReducer(reducerfun , [])

  useEffect(() => {
    fetch(initialstate)
      .then((res) => { return res.json() })
      .then((data) => { dispatch({type : "print" , payload : data}) })
  }, [])

  const name = {name : data}

  const handleAdd = ()=>{
    fetch(initialstate,{
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(name),
    })
    .then((res)=>{return res.json()})
    .then((data)=>{ dispatch({type : "Add" , payload : data})})
}

     


  return (
    <>
      <h2 className='pb-5'>Reducer Json Crud</h2>


      <input type='text' value={data} onChange={(e)=>{setData(e.target.value)}}></input> <button onClick={handleAdd} className='btn btn-info'>Add</button>

      {state && state.map((value) => {
        return (
          <li key={value.id}>
           <Button data={value} dispatch={dispatch}></Button>
          </li>
        )
      })}
    </>
  )
}



function Button({data , dispatch}) {

  // console.log(data)
  const [show, setShow] = useState(true)
  const [name,setName] = useState(data.name)
  
  
const upitem = {id : data.id , name}


  const handleEdit = ()=>{
    setShow(true)

    fetch(`${initialstate}/${data.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(upitem),
    })
    .then((res)=>{return res.json()})
    .then((udata)=>{ dispatch({type : "edit" , payload : udata})})
  }


  const handleDelete = ()=>{
    fetch(`${initialstate}/${data.id}`, {
      method: "Delete",
    })
    dispatch({type:"del" , payload:{id : data.id}})
    // window.location.reload()
  }
  let btn;
  if (show) {
    btn = 
    <>
      {data.name}
      <button onClick={
        ()=>{setShow(false)}}  className='btn btn-success mx-3 my-2'>Edit</button>
    </>
  }

     

  else {
    btn = <>
      <input type='text'  value={name} onChange={(e)=>{setName(e.target.value)}}></input>
      <button onClick={handleEdit} className='btn btn-warning mx-3 my-2'>Save</button>
        
               
      
       
       
    </>
  }


        
         
          
        
      
  return (
    <>
      {btn}
      <button className='btn btn-danger' onClick={handleDelete}>Delete</button>
    </>
  )
}

export default ReducerJsonCrud

