import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function StateJsonCrud() {
    const [data,setData] = useState([])
    const [name,setName] = useState("")
    useEffect(()=>{
        fetch('http://localhost:1234/data')
        .then((res)=>{return res.json()})
        .then((data)=>{setData(data)})
    })


    const handleDelete =(id)=>{
        fetch(`http://localhost:1234/data/${id}`,{
            method:"delete",
            headers:{"content-type":"application/json"},
           
        })  
    }
      
  const handleAdd =()=>{
    fetch('http://localhost:1234/data',{
        method:"post",
        headers:{"content-type":"application/json"},
        body:JSON.stringify({name})
    },[])
  }

        
  return (  
    <>
    <h2 className='pb-5'>State Json Crud</h2>

       <label>Name : </label> <input type='text' value={name} onChange={(e)=>{setName(e.target.value)}}></input> 
    <button className='btn btn-warning' onClick={handleAdd}>Add Data</button>
    <table className='App table container' border="1">
        <thead className='table-dark'>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {data.map((val)=>{
              return(
                <>
                <tr key={val.id}>
                  <td>{val.id}</td>
                  <td>{val.name}</td>
                  <td>
                  <Link className="btn btn-info mx-2" to={`/edit/${val.id}`}>Edit</Link>
                    <button onClick={()=>{handleDelete(val.id)}} className='btn btn-danger'>Delete</button>
                  </td>
                </tr>
                </>
              )
          })}
        </tbody>
      </table>
    </>
  )
}



export default StateJsonCrud