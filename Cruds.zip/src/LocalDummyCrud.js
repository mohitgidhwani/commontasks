import React, { useState } from 'react'

function LocalDummyCrud() {



    let [name, setName] = useState("")
    let [age, setAge] = useState("")
    let [address, setAddress] = useState("")
    let [phone, setPhone] = useState("")
    let [uid, setId] = useState("")

    console.log(uid)

    let content = JSON.parse(localStorage.getItem('Users')) ?? []

    let id = 0

    const add = () => {
        content.length != id ? content.findLast((user) => id = user.id) : id = 0
    
        if(uid)
        {
          content.map((value)=>{
            if(uid == value.id)
            {   
                value.name = name
                value.age = age
                value.address = address
                value.phone = phone
            }
          })
        }
        else
        {
            const user = {
                id: id + 1,
                name: name,
                age: age,
                address: address,
                phone: phone
            }
            content.push(user)
        }
       
        // localStorage.setItem("Users", JSON.stringify(content))
        window.location.reload()
    }





    const handleDelete = (id) => {
        content = content.filter((value) => {
            return value.id !== id;
        })
        // localStorage.setItem('Users', JSON.stringify(content))
        window.location.reload()
    }



    const handleEdit = (id) => {
        let content = JSON.parse(localStorage.getItem('Users')) ?? []

        content.map((value) => {
            if (value.id == id) {
                setId(value.id)
                setName(value.name)
                setAge(value.age)
                setAddress(value.address)
                setPhone(value.phone)
            }
        })
    }




    return (
        <>
            <h2 className='pb-5'>Reducer Json Crud</h2>
            <div className='container text-center w-25'>
                <form id="form">
                    <input type="text" readOnly className="form-control" name="id" value={uid}  />
                    <label >Name</label>
                    <input type="text" placeholder="Name" className="form-control" name="name" id="name" value={name} onChange={(e) => { setName(e.target.value) }} />
                    <br />
                    <label >Age</label>
                    <input type="number" placeholder="Age" className="form-control" name="age" id="age" value={age} onChange={(e) => { setAge(e.target.value) }} />
                    <br />
                    <label >Address</label>
                    <textarea name="address" placeholder="Address" id="address" cols={30} rows={5} className="form-control" value={address} onChange={(e) => { setAddress(e.target.value) }} />
                    <br />
                    <label >Phone</label>
                    <input type="text" placeholder="Phone" className="form-control" id="phone" name="phone" value={phone} onChange={(e) => { setPhone(e.target.value) }} />
                    <br />
                    <button className="btn btn-sm btn-primary mx-2" type="button" onClick={add}>Save</button>
                    <button className="btn btn-sm btn-primary mx-2" type="button" >Reset</button>
                </form>
            </div>
            <table className='table container mt-5'>
                <thead className='table table-dark'>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {content.map((value) => {
                        return (

                            <tr key={value.id}>
                                <td>{value.name}</td>
                                <td>{value.age}</td>
                                <td>{value.address}</td>
                                <td>{value.phone}</td>
                                <td>
                                    <button className='btn btn-warning mx-2' onClick={() => { handleEdit(value.id) }}>Edit</button>
                                    <button className='btn btn-danger' onClick={() => { handleDelete(value.id) }}>Delete</button>
                                </td>
                            </tr>

                        )
                    })}
                </tbody>
            </table>
        </>
    )
}

export default LocalDummyCrud































