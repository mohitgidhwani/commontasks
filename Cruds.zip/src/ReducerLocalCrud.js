import { type } from '@testing-library/user-event/dist/type'
import React, { useReducer, useState } from 'react'

const inisitalState = JSON.parse(localStorage.getItem('Users')) ?? []


const reducerFun = (state,action)=>{
   console.log(state)
   console.log(action.payload)

   switch(action.type)
   {
    case "add" : 
    return [...state,action.payload]
   }
}

    function ReducerLocalCrud() {

        const [name,setNmae] = useState("")

        const [state, disptach] = useReducer(reducerFun, inisitalState)
          
        let id=0;
       
        const handleAdd = ()=>{
           const data = {
            id : id=1,
            name:name
           }
            disptach({type : "add" , payload : data})
            localStorage.setItem("data",JSON.stringify(state))
       
        }

        return (
            <div>
                <h2 className='pb-5'>Reducer Local Crud</h2>
                <div className='mb-5 container'>
                    <form >
                        <label>Name : </label> 
                        <input type='text' className='form-control w-25 m-auto' value={name} onChange={(e)=>{setNmae(e.target.value)}}></input>
                        <input type='button' className='btn btn-info' onClick={handleAdd} value={"ADD"}></input>
                    </form>
                </div>

                <br></br>
                <div className='container'>
                    <table className='table'>
                        <thead className='table-dark'>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                             
                        </tbody>
                    </table>
                </div>
            </div>

        )
    }

export default ReducerLocalCrud

            



