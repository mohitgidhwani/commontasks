import { type } from '@testing-library/user-event/dist/type'
import React, { useReducer, useState } from 'react'


const array = [
    { id: 1, name: "Mohit" },
    { id: 2, name: "Raju" }
]



const reducerfun = (state, action) => {
    switch (action.type) {
        case "add":
            return [...state , {id:state.length + 1 ,name : action.payload}];


        case "Edit" : 
            return state.map((value)=>{
                 if(value.id == action.payload.id)
                 {
                    return action.payload
                 }
                 else
                 {
                    return value
                 }
            })

            case "Del" : 
            return state.filter((value)=>{
                return value.id !== action.payload
            })
            
    }
}
   
  
 


   

function ReducerDummyCrud() {

    const [state, dispatch] = useReducer(reducerfun, array)
    const [name, setName] = useState("")

    const handleAdd = () => {
        dispatch({ type: "add", payload: name });
    }

   
  
    return (
        <>
            <h2 className='pb-5'>Reducer Dummy Crud</h2>

            <input type='text' value={name} onChange={(e) => { setName(e.target.value) }}></input> <button onClick={handleAdd} className='btn btn-info'>Add</button>
            {state.map((value) => {
                return (
                    <>
                        <li key={value.id}>
                            <Buttons arraydata={value} dispatch={dispatch}></Buttons>
                        </li>
                    </>
                )
            })}
        </>
    )
}
  

   

    
   



function Buttons({ arraydata , dispatch }) {
    const [show, setShow] = useState(true)
    const [edit,setEdit] = useState(arraydata.name)
     console.log(edit)
    let btn;

    if (show) {
        btn = <>
             
            {arraydata.name}
            <button onClick={() => { setShow(false) }} className='btn btn-success mx-3 my-2'>Edit</button>
        </>
    }
    else {
        btn = <>
            <input type='text' value={edit}  onChange={(e)=>{setEdit(e.target.value)}}></input>


            <button onClick={
                ()=>{
                    setShow(true);
                   dispatch({type : "Edit" , payload : {id:arraydata.id , name : edit}})
                }
                } className='btn btn-warning mx-3 my-2'>Save</button>
        </>
    }

    const handleDelete = ()=>{
        dispatch({type:"Del" , payload : arraydata.id})
    }

    return (
        <>
            {btn}
            <button className='btn btn-danger' onClick={handleDelete}>Delete</button>



        </>
    )
}

export default ReducerDummyCrud