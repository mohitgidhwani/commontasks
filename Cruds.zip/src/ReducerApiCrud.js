import { type } from '@testing-library/user-event/dist/type';
import React, { useEffect, useReducer, useState } from 'react'

const initialstate = 'https://jsonplaceholder.typicode.com/users'


const reducerfun = (state,action)=>{
     switch(action.type)
     {
        case "print" :
            return action.payload


            case "add" :
                return   [...state , {id:state.length + 1 ,name : action.payload}];


            case "edit" : 
            return state.map((value)=>{
                  if(value.id == action.payload.id)
                  {
                    return action.payload
                  }
                  else
                  {
                    return value
                  }
            })


            case "del" : 
            return state.filter((value)=>{
                return value.id !== action.payload
            })
     }
}

function ReducerApiCrud() {


    const [state,dispatch] = useReducer(reducerfun , [])
    const [name,setName] = useState("")

    useEffect(()=>{
        fetch(initialstate)
        .then((res)=>{return res.json()})
        .then((data)=>{
            dispatch({type:"print" , payload: data})
        })
    },[])

    const handleAdd = ()=>{
        dispatch({type : "add" , payload : name})
    }

    return (
        <>
            <h2 className='pb-5'>Reducer Json Crud</h2>


            <input type='text' value={name} onChange={(e)=>{setName(e.target.value)}}></input> <button className='btn btn-info' onClick={handleAdd}>Add</button>
            {state.map((value)=>{
               return(
                <li key={value.id}>
                    <Button data={value} dispatch={dispatch}></Button>
                </li>
               )
            })}
        </>
    )
}


function Button({data , dispatch})
{
    const [show, setShow] = useState(true)
    const [name,setName] = useState(data.name)


    const handleEdit = ()=>{
        setShow(true)

        dispatch({type : "edit" , payload : {id:data.id,name : name}})
    }

    const handleDelete = ()=>{
        dispatch({type : "del" , payload:data.id})
    }

    let btn;

     if (show) {
        btn = 
        <>
          {data.name}
          <button onClick={()=>{setShow(false)}}  className='btn btn-success mx-3 my-2'>Edit</button>
           
        </>
      }
      else {
        btn =
         <>
          <input type='text'  value={name} onChange={(e)=>{setName(e.target.value)}}></input>
          <button onClick={handleEdit} className='btn btn-warning mx-3 my-2'>Save</button>
        </>
      }
    
         
    
            
                   
          
           
           
    return(
        <>
        {btn}
        <button className='btn btn-danger' onClick={handleDelete}>Delete</button>
        </>
    )
}

export default ReducerApiCrud