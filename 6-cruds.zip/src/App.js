import logo from './logo.svg';
import './App.css';
import TodoData from './StateDummyCrud';
import StateDummyCrud from './StateDummyCrud';
import StateJsonCrud from './StateJsonCrud';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import StateJsonEdit from './StateJsonEdit';
import StateApiCrud from './StateApiCrud';
import ReducerDummyCrud from './ReducerDummyCrud';
import ReducerJsonCrud from './ReducerJsonCrud';
import ReducerApiCrud from './ReducerApiCrud';
import LocalDummyCrud from './LocalDummyCrud';



function App() {
  return (
    <div className="App">
      <div className='State-Dummy-Crud'>
        {/* <StateDummyCrud></StateDummyCrud> */}
      </div>
      <div className='State-Json-Crud'>
        {/* <BrowserRouter>
        <Routes>
          <Route path='/' element={<StateJsonCrud></StateJsonCrud>}></Route>
          <Route path='/edit/:id' element={<StateJsonEdit></StateJsonEdit>}></Route>
        </Routes>
      </BrowserRouter> */}
      </div>
      <div className='State-Api-Crud'>
        {/*<StateApiCrud></StateApiCrud>*/}
      </div>
      <div className='Reducer-Dummy-Crud'>
        {/*<ReducerDummyCrud></ReducerDummyCrud>*/}
      </div>
      <div className='Reducer-Json-Crud'>
        {/* <ReducerJsonCrud></ReducerJsonCrud> */}
      </div>
      <div className='Reducer-Api-Crud'>
        {/* <ReducerApiCrud></ReducerApiCrud> */}
      </div>
      <div>
         <LocalDummyCrud></LocalDummyCrud>
      </div>
          
        


    </div>
  );
}

export default App;