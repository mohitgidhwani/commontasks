import React, { useState } from 'react'


let index = 3
function StateDummyCrud()
{
    const array = [
        {"id":1,"name":"Mohit"},
        {"id":2,"name":"Raju"}
      ]
      
      const [data,setData] = useState("")

      const [arr,setArr] = useState(array)

      
     

      const handleAdd = (name)=>{
          
          setArr(
            [...arr,
                {"id":index++,"name":name}
            ]
          )
      }


      const handleedit = (data)=>{
         setArr (arr.map((value)=>{
             if(value.id == data.id)
             {
                return data
             }
             else
             {
                return value
             }
         }))
        }

       const handleDelete =(id)=>{
         setArr(arr.filter((value)=>{
              return value.id !== id
         }))
       }
  
      
      
    return(
        <>
        <h2 className='pb-5'>State Dummy Crud</h2>

        <input type='text' value={data} onChange={(e)=>{setData(e.target.value)}}></input> <button className='btn btn-info' onClick={()=>{handleAdd(data)}}>Add</button>

            {arr.map((value)=>{
                    return(
                        <>
                       <li key={value.id}>
                           <Buttons arraydata={value} editdata={handleedit} deleteData={handleDelete}></Buttons>
                       </li>
                           
                        </>
                    )
            })}
        </>
    )
}

function Buttons({arraydata , editdata , deleteData}) {

    const [show,setShow] = useState(true)


    let btn;

    if(show)
    {
           btn = <>
            {arraydata.name}
            <button onClick={()=>{setShow(false)}} className='btn btn-success mx-3 my-2'>Edit</button>
           </>
    }
    else
    {
        btn =  <>
        <input type='text' value={arraydata.name} onChange={(e)=>{
             editdata(
                {...arraydata,
                    name:e.target.value
                }
             )
        }} ></input>
        
        <button onClick={()=>{setShow(true)}} className='btn btn-warning mx-3 my-2'>Save</button>
        </>
    }
  return (
   <>
        
          
        {btn}
       <button className='btn btn-danger' onClick={()=>{
        
           deleteData(arraydata.id)
       }}>Delete</button>
       
      
   </>
  )
}

export default StateDummyCrud